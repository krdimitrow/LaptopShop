package com.example.football.models.entity.en;

public enum Position {
    ATT,MID,DEF
}
